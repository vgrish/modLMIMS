<?php
require_once (dirname(dirname(__FILE__)) . '/modlmims.class.php');
class modLMIMS_mysql extends modLMIMS {}