--------------------
modLMIMS
--------------------
Author: Kartashov Alexey <ya.antixrist@gmail.com>
--------------------

"<b>L</b>ast <b>M</b>odified", "<b>I</b>f <b>M</b>odified <b>S</b>ince".

Самая что ни на есть корректная отдача заголовка - "304 Last Modified".